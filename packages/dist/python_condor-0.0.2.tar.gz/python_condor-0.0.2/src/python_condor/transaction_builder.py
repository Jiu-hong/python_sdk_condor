from __future__ import annotations

from python_condor.constants.cons_target import TargetKind
from python_condor.transaction_target import TransactionTarget
from .transaction_invocation_target import TransactionInvocationTarget
from .transaction_v1_payload import TransactionV1Payload
from .transaction_v1 import TransactionV1
from .constants import InvocationKind

# payload = TransactionV1Payload(self.initiatorAddr, self.timestamp, self.ttl, self.chain_name,  self.pricing_mode, self.args, self.target,
#                                self.entrypoint, self.scheduling)
# transaction = TransactionV1(
#     payload, self.signers_keypaths_algo)


INVOCATIONKIND = InvocationKind()
TARGETKIND = TargetKind()
# print("CONST:", CONST)


class TransactionBuilder:
    def __init__(self, initiator_addr, chain_name, timestamp, ttl, pricing_mode, invocation_target, entry_point, _scheduling, _runtimeArgs, _contractHash):
        self.initiator_addr = initiator_addr
        self.chain_name = chain_name
        self.timestamp = timestamp
        self.ttl = ttl
        self.pricing_mode = pricing_mode
        pass

        # abstract class TransactionBuilder < T extends TransactionBuilder < T >> {
        #     protected _initiatorAddr!: InitiatorAddr
        #     protected _chainName!: string
        #     protected _timestamp = new Timestamp(new Date())
        #     protected _ttl = new Duration(1800000)
        #     protected _pricingMode!: PricingMode
        #     protected _invocationTarget!: TransactionTarget
        #     protected _entryPoint!: TransactionEntryPoint
        #     protected _scheduling: TransactionScheduling = new TransactionScheduling({})
        #     // Standard
        #     protected _runtimeArgs: Args
        #     protected _contractHash: string

        #     / **
        #     * Sets the initiator address using a public key.
        #     * /
        #     public from (publicKey: PublicKey): T {
        #         this._initiatorAddr = new InitiatorAddr(publicKey)
        #         return (this as unknown) as T
        #     }

        #     / **
        #     * Sets the initiator address using an account hash.
        #     * /
        #     public fromAccountHash(accountHashKey: AccountHash): T {
        #         this._initiatorAddr = new InitiatorAddr(undefined, accountHashKey)
        #         return (this as unknown) as T
        #     }

        #     / **
        #     * Sets the chain name for the transaction.
        #     * /
        #     public chainName(chainName: string): T {
        #         this._chainName = chainName
        #         return (this as unknown) as T
        #     }

        #     / **
        #     * Sets the contract hash for the transaction.
        #     * /
        #     public contractHash(contractHash: string): T {
        #         this._contractHash = contractHash
        #         return (this as unknown) as T
        #     }

        #     / **
        #     * Sets the timestamp for the transaction.
        #     * /
        #     public timestamp(timestamp: Timestamp): T {
        #         this._timestamp = timestamp
        #         return (this as unknown) as T
        #     }

        #     / **
        #     * Sets the time-to-live for the transaction.
        #     * /
        #     public ttl(ttl: number): T {
        #         this._ttl = new Duration(ttl)
        #         return (this as unknown) as T
        #     }

        #     / **
        #     * Sets the payment amount for the transaction.
        #     * /
        #     public payment(paymentAmount: number, gasPriceTolerance=1): T {
        #         const pricingMode = new PricingMode()
        #         const paymentLimited = new PaymentLimitedMode()
        #         paymentLimited.standardPayment = true
        #         paymentLimited.paymentAmount = paymentAmount
        #         paymentLimited.gasPriceTolerance = gasPriceTolerance

        #         pricingMode.paymentLimited = paymentLimited
        #         this._pricingMode = pricingMode
        #         return (this as unknown) as T
        #     }

        #     protected _getDefaultDeployHeader(): DeployHeader {
        #         const deployHeader = DeployHeader.default()
        #         deployHeader.account = this._initiatorAddr.publicKey
        #         deployHeader.chainName = this._chainName
        #         deployHeader.timestamp = this._timestamp
        #         deployHeader.ttl = this._ttl

        #         return deployHeader
        #     }

        #     protected _getStandardPayment(): ExecutableDeployItem {
        #         if (!this._pricingMode.paymentLimited?.paymentAmount) {
        #             throw new Error('PaymentAmount is not specified')
        #         }

        #         return ExecutableDeployItem.standardPayment(
        #             this._pricingMode.paymentLimited.paymentAmount.toString()
        #         )
        #     }
    def build(self) -> TransactionV1:
        payload = TransactionV1Payload(self.initiatorAddr, self.timestamp, self.ttl, self.chain_name,  self.pricing_mode, self.args, self.target,
                                       self.entrypoint, self.scheduling)
        transaction = TransactionV1(
            payload, self.signers_keypaths_algo)
        return transaction.to_json()
        #     / **
        #     * Builds and returns the Transaction instance.
        #     * /
        #     public build(): Transaction {
        #         const transactionPayload = TransactionV1Payload.build({
        #             initiatorAddr: this._initiatorAddr,
        #             timestamp: this._timestamp,
        #             ttl: this._ttl,
        #             chainName: this._chainName,
        #             pricingMode: this._pricingMode,
        #             args: this._runtimeArgs,
        #             transactionTarget: this._invocationTarget,
        #             entryPoint: this._entryPoint,
        #             scheduling: this._scheduling
        #         })

        #         const transactionV1 = TransactionV1.makeTransactionV1(transactionPayload)
        #         return Transaction.fromTransactionV1(transactionV1)
        #     }
        # }


class ContractCallBuilder(TransactionBuilder):
    # export class ContractCallBuilder extends TransactionBuilder<
    #   ContractCallBuilder
    # > {
    #   constructor() {
    #     super();
    #   }

    #   private _transactionInvocationTarget: TransactionInvocationTarget;
    def by_hash(self, contract_hash: str) -> ContractCallBuilder:
        # invocation_target = TransactionInvocationTarget(
        #     CONST.INVOCABLEENTITY, contract_hash)
        target = TransactionTarget(TARGETKIND.STORED, INVOCATIONKIND.INVOCABLEENTITY,
                                   contract_hash)
        return target

        #   public byHash(contractHash: string): ContractCallBuilder {
        #     const invocationTarget = new TransactionInvocationTarget();
        #     invocationTarget.byHash = Hash.fromHex(contractHash);
        #     this._transactionInvocationTarget = invocationTarget;

        #     const storedTarget = new StoredTarget();
        #     storedTarget.id = invocationTarget;
        #     storedTarget.runtime = TransactionRuntime.vmCasperV1();

        #     this._invocationTarget = new TransactionTarget(undefined, storedTarget);
        #     return this;
        #   }

        #   public byName(name: string): ContractCallBuilder {
        #     const invocationTarget = new TransactionInvocationTarget();
        #     invocationTarget.byName = name;
        #     this._transactionInvocationTarget = invocationTarget;

        #     const storedTarget = new StoredTarget();
        #     storedTarget.id = invocationTarget;
        #     storedTarget.runtime = TransactionRuntime.vmCasperV1();

        #     this._invocationTarget = new TransactionTarget(undefined, storedTarget);
        #     return this;
        #   }

        #   public byPackageHash(
        #     contractHash: string,
        #     version?: number
        #   ): ContractCallBuilder {
        #     const packageHashInvocationTarget = new ByPackageHashInvocationTarget();
        #     packageHashInvocationTarget.addr = Hash.fromHex(contractHash);
        #     packageHashInvocationTarget.version = version;
        #     const transactionInvocationTarget = new TransactionInvocationTarget();
        #     transactionInvocationTarget.byPackageHash = packageHashInvocationTarget;
        #     this._transactionInvocationTarget = transactionInvocationTarget;

        #     const storedTarget = new StoredTarget();

        #     storedTarget.id = transactionInvocationTarget;
        #     storedTarget.runtime = TransactionRuntime.vmCasperV1();

        #     this._invocationTarget = new TransactionTarget(undefined, storedTarget);
        #     return this;
        #   }

        #   public byPackageName(name: string, version?: number): ContractCallBuilder {
        #     const packageNameInvocationTarget = new ByPackageNameInvocationTarget();
        #     packageNameInvocationTarget.name = name;
        #     packageNameInvocationTarget.version = version;
        #     const transactionInvocationTarget = new TransactionInvocationTarget();
        #     transactionInvocationTarget.byPackageName = packageNameInvocationTarget;
        #     this._transactionInvocationTarget = transactionInvocationTarget;

        #     const storedTarget = new StoredTarget();

        #     storedTarget.id = transactionInvocationTarget;
        #     storedTarget.runtime = TransactionRuntime.vmCasperV1();

        #     this._invocationTarget = new TransactionTarget(undefined, storedTarget);

        #     return this;
        #   }

        #   public entryPoint(name: string): ContractCallBuilder {
        #     this._entryPoint = new TransactionEntryPoint(
        #       TransactionEntryPointEnum.Custom,
        #       name
        #     );
        #     return this;
        #   }

        #   public runtimeArgs(args: Args): ContractCallBuilder {
        #     this._runtimeArgs = args;
        #     return this;
        #   }

        #   public buildFor1_5(): Transaction {
        #     if (!this._entryPoint.customEntryPoint) {
        #       throw new Error('EntryPoint is not specified');
        #     }

        #     const session = new ExecutableDeployItem();

        #     if (this._transactionInvocationTarget.byHash) {
        #       session.storedContractByHash = new StoredContractByHash(
        #         ContractHash.newContract(
        #           this._transactionInvocationTarget.byHash.toHex()
        #         ),
        #         this._entryPoint.customEntryPoint,
        #         this._runtimeArgs
        #       );
        #     } else if (this._transactionInvocationTarget.byPackageHash) {
        #       session.storedVersionedContractByHash = new StoredVersionedContractByHash(
        #         ContractHash.newContract(
        #           this._transactionInvocationTarget.byPackageHash.addr.toHex()
        #         ),
        #         this._entryPoint.customEntryPoint,
        #         this._runtimeArgs,
        #         this._transactionInvocationTarget.byPackageHash.version
        #       );
        #     } else if (this._transactionInvocationTarget.byName) {
        #       session.storedContractByName = new StoredContractByName(
        #         this._transactionInvocationTarget.byName,
        #         this._entryPoint.customEntryPoint,
        #         this._runtimeArgs
        #       );
        #     } else if (this._transactionInvocationTarget.byPackageName) {
        #       session.storedVersionedContractByName = new StoredVersionedContractByName(
        #         this._transactionInvocationTarget.byPackageName.name,
        #         this._entryPoint.customEntryPoint,
        #         this._runtimeArgs,
        #         this._transactionInvocationTarget.byPackageName.version
        #       );
        #     }

        #     const deploy = Deploy.makeDeploy(
        #       this._getDefaultDeployHeader(),
        #       this._getStandardPayment(),
        #       session
        #     );

        #     return Transaction.fromDeploy(deploy);
        #   }
        # }
