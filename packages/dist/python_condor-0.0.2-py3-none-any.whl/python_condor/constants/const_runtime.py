from .base import constant


class RuntimeKind(object):
    @constant
    def VMCASPERV1():
        return "VmCasperV1"
