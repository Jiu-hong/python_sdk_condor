from datetime import datetime, timezone
dt = datetime.fromisoformat('2025-03-24T00:49:13.133Z').timestamp()
print(dt)
dt1 = datetime.fromisoformat('2025-03-24T00:49:13.133Z')
print(dt1)
