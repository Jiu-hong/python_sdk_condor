from ...constants import TAG, Prefix, ClKeyTAG
PREFIX = Prefix()


class EntityAddr:
    def __init__(self, data):
        # check todo
        self.data = data

    def serialize(self):
        entity_data = self.data.removeprefix(PREFIX.ENTITY)
        if entity_data.startswith(PREFIX.SYSTEM):
            return int(0).to_bytes() + bytes.fromhex(entity_data.removeprefix(PREFIX.SYSTEM))
        elif entity_data.startswith(PREFIX.ACCOUNT):
            return int(1).to_bytes() + bytes.fromhex(entity_data.removeprefix(PREFIX.ACCOUNT))
        elif entity_data.startswith(PREFIX.CONTRACT):
            return int(2).to_bytes() + bytes.fromhex(entity_data.removeprefix(PREFIX.CONTRACT))
